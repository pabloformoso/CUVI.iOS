//
//  SWSecondViewController.h
//  AppSencilla
//
//  Created by Pablo Formoso Estada on 18/10/13.
//  Copyright (c) 2013 Pablo Formoso Estada. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SWSecondViewController : UIViewController
@property (weak, nonatomic) IBOutlet UILabel *etiqueta;

@end
