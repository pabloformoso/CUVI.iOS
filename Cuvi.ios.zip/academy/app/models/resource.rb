class Resource < ActiveRecord::Base
  attr_accessible :description, :link, :name
end
