module ResourcesHelper
end
