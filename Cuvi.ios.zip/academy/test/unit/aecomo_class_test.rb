require 'test_helper'

class AecomoClassTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
