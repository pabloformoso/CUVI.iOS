require 'test_helper'

class StundentTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
