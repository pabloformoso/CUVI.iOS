require 'test_helper'

class AecomoClassesHelperTest < ActionView::TestCase
end
