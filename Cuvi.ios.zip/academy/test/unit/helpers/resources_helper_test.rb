require 'test_helper'

class ResourcesHelperTest < ActionView::TestCase
end
