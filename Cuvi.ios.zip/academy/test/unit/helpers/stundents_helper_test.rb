require 'test_helper'

class StundentsHelperTest < ActionView::TestCase
end
