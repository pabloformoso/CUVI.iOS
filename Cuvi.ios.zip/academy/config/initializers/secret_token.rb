# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Academy::Application.config.secret_token = '013433d2236301954ff5a5f5fda9e4767bf71c4f6a6b80b7797b643f0a534f496428073b3006dcf4dc59c43b477d9d8084c714207962da5ef1748206cde6d5f8'
