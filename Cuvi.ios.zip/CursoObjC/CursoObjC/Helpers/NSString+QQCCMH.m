//
//  NSString+QQCCMH.m
//  CursoObjC
//
//  Created by Pablo Formoso Estada on 04/10/13.
//  Copyright (c) 2013 Pablo Formoso Estada. All rights reserved.
//
#import "NSString+QQCCMH.h"

@implementation NSString (QQCCMH)

- (NSString *)cadidataParaBodaDelAlumno {
  return [NSString stringWithFormat:@"%@ se casa con María", self];
}

@end
