//
//  NSString+QQCCMH.h
//  CursoObjC
//
//  Created by Pablo Formoso Estada on 04/10/13.
//  Copyright (c) 2013 Pablo Formoso Estada. All rights reserved.
//
@class Alumno;
#import <Foundation/Foundation.h>

@interface NSString (QQCCMH)

- (NSString *)cadidataParaBodaDelAlumno;

@end
